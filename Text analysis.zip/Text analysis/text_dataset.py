import torch
import pandas as pd
from transformers import AutoTokenizer


"""
Welcome to the TextDataset class! This is a pretty standard PyTorch Dataset class,
except that it also reads a text classification CSV from disk and tokenizes it.

The class takes three init arguments:
    path: the path of the CSV to read
    device: the torch device we're using
    max_sequence_len: the character limit for any example

The reading of the CSV and trimming has been handled for you, as has the
initialisation of the tokenizer, so all that's left in the __init__ function is
to tokenize the texts. We will set truncation and padding to True, so all of the
tokenised input is the same length, filled with zeros where necessary.

**Fill in the TODOs in the __init__ function**

Now we're just missing the __getitem__ function. This should grab the example and
label for the given index, initialise a tensor for each, and return them. Make
sure you place the tensors on the appropriate device using self.device.

**Fill in the TODOs in the __getitem__ function**

When you're finished, return to the "Write the Dataset Class" section of the notebook.
"""


class TextDataset(torch.utils.data.Dataset):
    def __init__(self, path, device=torch.device('cpu'), max_sequence_len=128):
        self.device = device

        df = pd.read_csv(path)
        texts = df['text'].str.slice(0, max_sequence_len).tolist()
        labels = df['label'].tolist()
        
        # TODO: set the tokenizer by using the AutoTokenizer to get 
        #       a tokenizer for the pretrained distilbert-base-uncased
        #       transformer
        # Solution
        tokenizer = AutoTokenizer.from_pretrained('distilbert-base-uncased')
        # Store the number of words in the tokenizer's vocabulary
        self.vocab_size = tokenizer.vocab_size
        # TODO: Call tokenizer with texts as an argument, setting the arguments
        # truncation and padding to True
        # tokens = ...
        # SOLUTION LINE
        tokens = tokenizer(texts, truncation=True, padding=True)

        # tokens is actually a dictionary with a few entries. We only want the
        # word IDs, so on the next line you should store the "input_ids" entry
        # in self.tokens
        # You should keep in mind that 'tokens' also has an "attention_mask" 
        # entry. In this lab we will not be using attention, which is why we 
        # won't be storing it.
        # self.tokens = ...
        # SOLUTION LINE
        self.tokens = tokens["input_ids"]
        
        self.labels = labels

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, idx):
        # Here we initialise a tensor for the inputs at the given index
        inputs = torch.tensor(self.tokens[idx], device=self.device)

        # TODO: Initialise a tensor for the label at the given index
        # label = ...
        label = torch.tensor(self.labels[idx], device=self.device)

        return inputs, label
