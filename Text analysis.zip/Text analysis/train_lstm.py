# Import required torch modules
import torch
from torch.utils.data import DataLoader

import wandb

# Import our own .py files - easy!
import trainer
from text_dataset import TextDataset
from metrics import classification_accuracy
from lstm import LSTM

"""
Running this file trains an LSTM model.

**Read through the code and fill in the TODOs**
"""


# Training parameters
BATCH_SIZE = 64
NUM_EPOCHS = 25
LEARNING_RATE = 1e-3

# LSTM model parameters
NUM_CLASSES = 2
EMBEDDING_DIMS = 512
NUM_LAYERS = 4
HIDDEN_DIMS = 256


def get_training_device():
    """Returns a device appropriate for training."""
    device = torch.device("cpu")
    if torch.cuda.is_available():
        device = torch.device("cuda:0")
        torch.cuda.set_device(device)
    return device


def train():
    #  TODO: Uncomment below when you get to the wandb visualization section
    # wandb.init(project="CSE5DL Transformer Lab", name="LSTM")

    torch.manual_seed(42)

    device = get_training_device()

    # TODO: Initialise two instances of TextDataset - one each for train and test.
    # Read the implementation in text_dataset.py if you're not sure which arguments
    # to provide.
    # train_dataset = ...
    # SOLUTION LINE
    train_dataset = TextDataset("dataset/train.csv", device)
    # test_dataset = ...
    # SOLUTION LINE
    test_dataset = TextDataset("dataset/test.csv", device)

    # TODO: Initialise a DataLoader for each dataset
    # train_loader = ...
    # SOLUTION LINE
    train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True)
    # test_loader = ...
    # SOLUTION LINE
    test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False)

    # TODO: Initialise an LSTM model. Check lstm.py if you're not sure which
    # arguments to provide. Hint: train_dataset has a vocab_size member variable
    # model = ...
    # SOLUTION LINE
    model =  LSTM(NUM_CLASSES, train_dataset.vocab_size, EMBEDDING_DIMS, NUM_LAYERS, HIDDEN_DIMS)

    # Move the model onto device
    model.to(device)

    # Initialise the optimizer and loss function
    optimizer = torch.optim.Adam(model.parameters(), lr=LEARNING_RATE)
    loss_func = torch.nn.CrossEntropyLoss()

    # The end-of-epoch callback has already been implemented. We compute test
    # loss and accuracy, then print out some results
    def epoch_callback(epoch, train_loss, train_accuracy):
        test_loss, test_accuracy, _ = trainer.test(model, test_loader, loss_func, classification_accuracy, device)
        print("Epoch: {}. Train loss, accuracy: {:.3f}, {:.3f}. Test loss, accuracy: {:.3f}, {:.3f}".format(
            epoch, train_loss, train_accuracy, test_loss, test_accuracy
        ))
    #  TODO: Uncomment below when you get to the wandb visualization section
    #    wandb.log({
    #         "train_loss": train_loss,
    #         "train_accuracy": train_accuracy,
    #         "test_loss": test_loss,
    #         "test_accuracy": test_accuracy
    #    })

    # Finally, train the model! 
    trainer.train(model,
                  train_loader,
                  NUM_EPOCHS,
                  loss_func,
                  classification_accuracy,
                  optimizer,
                  device,
                  epoch_callback)


if __name__ == "__main__":
    train()