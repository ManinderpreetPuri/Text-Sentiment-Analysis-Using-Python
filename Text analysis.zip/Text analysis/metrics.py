import torch

"""
Any metric implementations are kept here. Each metric takes a batch of
predictions as the first argument, and a batch of labels as the second.
"""

def classification_accuracy(predictions, targets):
    """
    Computes and returns classification accuracy, computed as:
        num_correct_predictions / num_total_predictions
    """
    predictions = predictions.argmax(1)
    correct = (predictions == targets).sum().item()
    acc = correct / len(targets)
    return acc
