import torch
from tqdm.notebook import tqdm


"""
Most of the code here is identical to previous labs, with a few exceptions.
Read through the functions and comments to understand the changes.

This function will be called at the end of each epoch, which allows us to perform
any evaluation and logging. This way, we can customise its functionality as we
deem appropriate.
"""


def through_model(model, inputs):
    """
    Convenience function to pass inputs through a model. If the model returns a
    tuple, its first element is returned. (This happens with the prebuilt transformer).
    """
    outputs = model(inputs)

    if isinstance(outputs, tuple):
        # Unpack the tuple
        outputs = outputs[0]

    return outputs


def train_step(model, inputs, labels, loss_func, accuracy_func, optimizer, device):
    """Perform a single training step including back-prop and optimisation"""
    model.train()
    optimizer.zero_grad()

    outputs = through_model(model, inputs)
    
    loss = loss_func(outputs, labels)
    accuracy = accuracy_func(outputs, labels)

    loss.backward()
    optimizer.step()

    return loss.item(), accuracy


def test_step(model, inputs, labels, loss_func, accuracy_func, device):
    """Perform a single test step"""
    model.eval()
    with torch.no_grad():
        outputs = through_model(model, inputs)
        loss = loss_func(outputs, labels)
        accuracy = accuracy_func(outputs, labels)

    return loss.item(), accuracy, outputs


def train(model, train_loader, num_epochs, loss_func, accuracy_func, optimizer, device, epoch_callback=None):
    """The training loop itself. Calls epoch_callback at the end of each epoch"""
    for epoch in tqdm(range(num_epochs)):
        running_loss = 0
        running_accuracy = 0

        for batch in train_loader:
            inputs, labels = batch
            loss, accuracy = train_step(model, inputs, labels, loss_func, accuracy_func, optimizer, device)
            running_loss += loss
            running_accuracy += accuracy

        epoch_loss = running_loss / len(train_loader)
        epoch_accuracy = running_accuracy / len(train_loader)

        # End of the epoch call the epoch callback with the current epoch, epoch loss and
        # accuracy as arguments (in that order). First check that the callback isn't
        # None before calling it!


        if epoch_callback:
            epoch_callback(epoch, epoch_loss, epoch_accuracy)



def test(model, test_loader, loss_func, accuracy_func, device):
    """Computes test accuracy and loss for the entire dataloader"""
    running_loss = 0
    running_accuracy = 0
    all_outputs = []

    for batch in test_loader:
        inputs, labels = batch
        loss, accuracy, outputs = test_step(model, inputs, labels, loss_func, accuracy_func, device)
        running_loss += loss
        running_accuracy += accuracy
        all_outputs.extend(outputs)

    loss = running_loss / len(test_loader)
    accuracy = running_accuracy / len(test_loader)

    return loss, accuracy, all_outputs