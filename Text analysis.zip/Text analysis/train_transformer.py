# Import required torch modules
import torch
from torch.utils.data import DataLoader


# TODO import the correct AutoModel transformer model type for our problem
#      Take a look here to find the correct one you want to import
#      https://huggingface.co/transformers/model_doc/auto.html#automodelforsequenceclassification
# from transformers import ...

# SOLUTION LINE
from transformers import AutoModelForSequenceClassification

import wandb

# Import our own .py files
import trainer
from text_dataset import TextDataset
from metrics import classification_accuracy
import utils


# Training parameters
BATCH_SIZE = 64
NUM_EPOCHS = 10
LEARNING_RATE = 1e-4


def train():
    wandb.init(project="CSE5DL Transformer Lab", name="Transformer")

    # TODO: Below we're calling a couple of functions in utils that don't yet
    # exist. Instead of writing the same seed code and get_training_device
    # function in every script, move the functions from train_lstm.py to utils.py

    # Seed the random number generator
    utils.seed_rng()
    # Select a training device
    device = utils.get_training_device()

    # TODO: Initialise the datasets and dataloaders - you can copy this code from
    # train_lstm.py

    # SOLUTION LINE
    train_dataset = TextDataset("dataset/train.csv", device)
    # SOLUTION LINE
    test_dataset = TextDataset("dataset/test.csv", device)
    # SOLUTION LINE
    train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True)
    # SOLUTION LINE
    test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False)

    # Here we load the pretrained model. We pass in the string name of the
    # checkpoint to load, and we are returned a trained model!
    # TODO: set the model to equal to a pretrained 'distilbert-base-uncased' model 
    #       using the correct type of AutoModel
    # model = ...
    model = AutoModelForSequenceClassification.from_pretrained('distilbert-base-uncased')

    # Move the model onto device
    model.to(device)

    # Initialise the optimizer and loss function
    optimizer = torch.optim.Adam(model.parameters(), lr=LEARNING_RATE)
    loss_func = torch.nn.CrossEntropyLoss()

    def epoch_callback(epoch, train_loss, train_accuracy):
        test_loss, test_accuracy, _ = trainer.test(model, test_loader, loss_func, classification_accuracy, device)
        wandb.log({
            "train_loss": train_loss,
            "train_accuracy": train_accuracy,
            "test_loss": test_loss,
            "test_accuracy": test_accuracy
        })

    trainer.train(model,
                  train_loader,
                  NUM_EPOCHS,
                  loss_func,
                  classification_accuracy,
                  optimizer,
                  device,
                  epoch_callback)
        
    # SOLUTION LINE
    utils.save_model_state(model, "transformer")


if __name__ == "__main__":
    train()