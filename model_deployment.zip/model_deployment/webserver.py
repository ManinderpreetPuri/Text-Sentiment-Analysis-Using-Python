import os
import requests
import json

from flask import Flask, request, send_from_directory
from flask_ngrok import run_with_ngrok

"""
A basic web server which provides two endpoints.

GET /
    Serves the static HTML file which is the app interface.

POST /predict
    Predicts text sentiment for the given string. Requests are forwarded to
    the prediction server URI provided in the `start` function.
    Expects as input a JSON string formatted like:
    { "input_str": "Some text to classify" }
    Its response is formatted like:
    { "result": "Positive" }
"""


# This value will be set when the server is started
scoring_uri = None
# Create the Flask app
app = Flask(__name__)


@app.route('/', methods=['GET'])
def index():
    """Serve the static html file"""
    return send_from_directory(os.getcwd(), 'index.html')


@app.route('/predict', methods=['POST'])
def predict():
    """Make a sentiment prediction with the given string"""
    if "input_str" not in request.json:
        return {
            "result": "Request must contain 'input_str' key"
        }, 400
    input_str = request.json["input_str"]
    
    # Make a post request at our specified URI with the input string
    resp = requests.post(url=scoring_uri,
                         json=input_str)
    # Decode the response from json to a regular string
    sentiment = resp.json()
    
    return {
        "result": sentiment
    }


def start(uri):
    """Set the remote server address and start the webserver"""
    global scoring_uri
    scoring_uri = uri

    # Wrap the app with ngrok
    run_with_ngrok(app)
    # Start the server
    app.run()

    