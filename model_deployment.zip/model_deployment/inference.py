import os

import torch
from transformers import AutoModelForSequenceClassification, AutoTokenizer


"""
Minimal inference script for Azure ML.
Usage:
# Once only:
import inference
inference.init()

# For each request:
inference.run(string_to_classify)
"""


def get_training_device():
    """Returns a device appropriate for training."""
    device = torch.device("cpu")
    if torch.cuda.is_available():
        device = torch.device("cuda:0")
        torch.cuda.set_device(device)
    return device


def load_model_state(model, name, device):
    """Restore model weights from the given file name"""
    # Build the full file path (note the Azure model directory)
    path = os.path.join(os.getenv('AZUREML_MODEL_DIR'), 'model_weights', name + ".pth")

    # Check that the weights exist
    if os.path.exists(path):
        # Load the model weights from disk
        model.load_state_dict(torch.load(path, map_location=device))
        print("Model state loaded from", path)
    else:
        print("No weights found with this name - no action taken...")


def through_model(model, inputs):
    """
    Convenience function to pass inputs through a model. If the model returns a
    tuple, its first element is returned. (This happens with the prebuilt transformer).
    """
    outputs = model(inputs)

    if isinstance(outputs, tuple):
        # Unpack the tuple
        outputs = outputs[0]

    return outputs


def init():
    global model, tokenizer, device

    # Load the model from huggingface
    device = get_training_device()
    model =  AutoModelForSequenceClassification.from_pretrained('distilbert-base-uncased')
    model.to(device)

    # Load model weights from disk and initialise the tokenizer
    load_model_state(model, 'transformer', device)
    tokenizer = AutoTokenizer.from_pretrained('distilbert-base-uncased')


def run(input_str):
    global model, tokenizer
    try:
        # Tokenize the given string
        encodings = tokenizer(input_str, truncation=True, padding=True)
        # Make tensor on the device
        inputs = torch.tensor(encodings['input_ids'], device=device)
        # Add batch dimension
        inputs = inputs.unsqueeze(0)

        # Get model predictions
        outputs = through_model(model, inputs)
        # Convert to a value of 0 or 1 (for negative/positive sentiment)
        sentiment = torch.argmax(outputs, -1)
        # Take only the first prediction (as we have a batch size of 1)
        sentiment = sentiment[0]

        return 'Positive' if sentiment == 1 else 'Negative'
    except Exception as e:
        error = str(e)
        return error